package com.example.facturacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
